import { pgTable, text, serial, integer, numeric, timestamp, date, json, boolean, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Contacts model
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  subject: text("subject"),
  message: text("message").notNull(),
  created_at: timestamp("created_at").defaultNow(),
});

export const insertContactSchema = createInsertSchema(contacts).pick({
  name: true,
  email: true,
  phone: true,
  subject: true,
  message: true,
});

export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;

// Newsletter subscribers model
export const newsletters = pgTable("newsletters", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name"),
  subscribed_at: timestamp("subscribed_at").defaultNow(),
  active: integer("active").default(1),
});

export const insertNewsletterSchema = createInsertSchema(newsletters).pick({
  email: true,
  name: true,
});

export type InsertNewsletter = z.infer<typeof insertNewsletterSchema>;
export type Newsletter = typeof newsletters.$inferSelect;

// Donations model
export const donations = pgTable("donations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  amount: numeric("amount").notNull(),
  payment_method: text("payment_method").notNull(),
  recurring: integer("recurring").default(0),
  message: text("message"),
  donated_at: timestamp("donated_at").defaultNow(),
});

export const insertDonationSchema = createInsertSchema(donations).pick({
  name: true,
  email: true,
  amount: true,
  payment_method: true,
  recurring: true,
  message: true,
});

export type InsertDonation = z.infer<typeof insertDonationSchema>;
export type Donation = typeof donations.$inferSelect;

// Fact Check model
export const factChecks = pgTable("fact_checks", {
  id: serial("id").primaryKey(),
  claim: text("claim").notNull(),
  source: text("source"),
  category: text("category"),
  rating: text("rating").notNull(),
  analysis: text("analysis").notNull(),
  truthful_points: text("truthful_points"),
  misleading_points: text("misleading_points"),
  date_checked: timestamp("date_checked").defaultNow(),
});

export const insertFactCheckSchema = createInsertSchema(factChecks).pick({
  claim: true,
  source: true,
  category: true,
  rating: true,
  analysis: true,
  truthful_points: true,
  misleading_points: true,
});

export type InsertFactCheck = z.infer<typeof insertFactCheckSchema>;
export type FactCheck = typeof factChecks.$inferSelect;

// Document model for annotation
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  url: text("url"),
  userId: integer("user_id").references(() => users.id),
  isPublic: boolean("is_public").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertDocumentSchema = createInsertSchema(documents).pick({
  title: true,
  content: true,
  url: true,
  userId: true,
  isPublic: true,
});

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

// Annotations model
export const annotations = pgTable("annotations", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").references(() => documents.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  startOffset: integer("start_offset").notNull(),
  endOffset: integer("end_offset").notNull(),
  selectedText: text("selected_text").notNull(),
  comment: text("comment"),
  category: text("category").default("uncategorized"),
  verificationStatus: text("verification_status").default("unverified"),
  metadata: json("metadata").default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertAnnotationSchema = createInsertSchema(annotations).pick({
  documentId: true,
  userId: true,
  startOffset: true,
  endOffset: true,
  selectedText: true,
  comment: true,
  category: true,
  verificationStatus: true,
  metadata: true,
});

export type InsertAnnotation = z.infer<typeof insertAnnotationSchema>;
export type Annotation = typeof annotations.$inferSelect;

// Collaborators model
export const collaborators = pgTable("collaborators", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").references(() => documents.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  role: text("role").default("viewer"), // viewer, editor, owner
  invitedBy: integer("invited_by").references(() => users.id),
  invitedAt: timestamp("invited_at").defaultNow(),
  joinedAt: timestamp("joined_at"),
});

export const insertCollaboratorSchema = createInsertSchema(collaborators).pick({
  documentId: true,
  userId: true,
  role: true,
  invitedBy: true,
});

export type InsertCollaborator = z.infer<typeof insertCollaboratorSchema>;
export type Collaborator = typeof collaborators.$inferSelect;
