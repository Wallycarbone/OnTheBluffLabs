import express from "express";
import type { Express, Request, Response } from "express";
import { insertContactSchema, insertDonationSchema, insertFactCheckSchema, insertNewsletterSchema } from "@shared/schema";
import { storage } from "./storage";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<void> {
  const router = express.Router();

  // API route for checking server status
  router.get("/status", (req: Request, res: Response) => {
    res.json({ status: "ok", message: "API is working" });
  });

  // API route for contact form submissions
  router.post("/contact", async (req: Request, res: Response) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      
      res.json({ 
        success: true,
        message: "Thank you for your message. We'll get back to you soon!",
        contact 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid form data",
          errors: error.errors
        });
      }
      
      res.status(500).json({ 
        success: false, 
        message: "An error occurred while processing your request" 
      });
    }
  });

  // API route for newsletter subscriptions
  router.post("/newsletter", async (req: Request, res: Response) => {
    try {
      const newsletterData = insertNewsletterSchema.parse(req.body);
      const newsletter = await storage.subscribeToNewsletter(newsletterData);
      
      res.json({
        success: true,
        message: "Thank you for subscribing to our newsletter!",
        newsletter
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid subscription data",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "An error occurred while processing your subscription"
      });
    }
  });

  // API route for contributions
  router.post("/contribute", async (req: Request, res: Response) => {
    try {
      const donationData = insertDonationSchema.parse(req.body);
      const donation = await storage.createDonation(donationData);
      
      res.json({
        success: true,
        message: "Thank you for your contribution to Truth Networks Foundation!",
        donation
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid contribution data",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "An error occurred while processing your contribution"
      });
    }
  });

  // API route for fact-checking
  router.post("/fact-check", async (req: Request, res: Response) => {
    try {
      const factCheckData = insertFactCheckSchema.parse(req.body);
      const factCheck = await storage.checkFact(factCheckData);
      
      // Get rating class based on the rating
      const getRatingClass = (rating: string): string => {
        switch (rating.toLowerCase()) {
          case 'true':
            return 'true';
          case 'mostly true':
            return 'mostly-true';
          case 'mixed':
            return 'mixed';
          case 'mostly false':
            return 'mostly-false';
          case 'false':
            return 'false';
          default:
            return 'unknown';
        }
      };
      
      // Format the response with additional UI-friendly data
      const response = {
        ...factCheck,
        ratingClass: getRatingClass(factCheck.rating),
        analysisDate: new Date().toLocaleDateString(),
        truthful: factCheck.truthful_points || "",
        misleading: factCheck.misleading_points || ""
      };
      
      res.json(response);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid fact check data",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "An error occurred while processing your fact check request"
      });
    }
  });

  app.use("/api", router);
}
