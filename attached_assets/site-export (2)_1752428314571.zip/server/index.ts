import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { log, setupVite } from "./vite";
import http from "http";
import path from "path";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Middleware to log all requests
app.use((req, res, next) => {
  // Skip API routes logging for brevity
  if (!req.path.startsWith("/api")) {
    const start = Date.now();
    const path = req.path;
    
    res.on("finish", () => {
      const duration = Date.now() - start;
      log(`${req.method} ${path} ${res.statusCode} in ${duration}ms`);
    });
  }
  
  next();
});

(async () => {
  // Create HTTP server
  const server = http.createServer(app);
  
  // Setup Vite for development (passing both app and server)
  await setupVite(app, server);
  
  // Register our API routes
  await registerRoutes(app);

  // Error handling middleware
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    console.error(err);
  });

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`Server running at http://0.0.0.0:${port}/`);
  });
})();
