import express from 'express';
import path from 'path';
import { log } from './vite';

export function serveStaticSite(app: express.Express) {
  // Serve static files from the extracted_zip directory
  app.use(express.static(path.join(process.cwd(), 'extracted_zip')));

  // Handle all routes by serving index.html for client-side routing
  app.get('*', (req, res) => {
    const requestPath = req.path;

    // Check if the request is for a specific page and serve the corresponding HTML file
    if (requestPath === '/about') {
      res.sendFile(path.join(process.cwd(), 'extracted_zip', 'about.html'));
    } else if (requestPath === '/our-work') {
      res.sendFile(path.join(process.cwd(), 'extracted_zip', 'our-work.html'));
    } else if (requestPath === '/fact-checker') {
      res.sendFile(path.join(process.cwd(), 'extracted_zip', 'fact-checker.html'));
    } else if (requestPath === '/contact') {
      res.sendFile(path.join(process.cwd(), 'extracted_zip', 'contact.html'));
    } else if (requestPath === '/donate') {
      res.sendFile(path.join(process.cwd(), 'extracted_zip', 'donate.html'));
    } else {
      // Default to index.html
      res.sendFile(path.join(process.cwd(), 'extracted_zip', 'index.html'));
    }
  });

  log('Static site server is running');
  return app;
}