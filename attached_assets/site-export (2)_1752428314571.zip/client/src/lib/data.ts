export const coreValues = [
  {
    id: 1,
    title: "Truth",
    description: "We stand for clarity and accuracy in a world flooded with misinformation, always prioritizing facts over manipulation.",
    color: "primary",
  },
  {
    id: 2,
    title: "Independence",
    description: "We operate free from political agendas, corporate interests, and platform influence to provide truly unbiased fact-checking.",
    color: "secondary",
  },
  {
    id: 3,
    title: "Transparency",
    description: "We believe in open methods, clear sources, and accessible tools that empower people to verify information themselves.",
    color: "accent",
  },
];

export const services = [
  {
    id: 1,
    title: "Real-Time Fact-Checking",
    description: "We deliver instant verification of news and information to combat the spread of falsehoods.",
    icon: "CheckCircle",
    color: "green",
  },
  {
    id: 2,
    title: "Free Verification Tool",
    description: "Our open-source tool empowers users to verify the accuracy of content they encounter online.",
    icon: "Search",
    color: "blue",
  },
  {
    id: 3,
    title: "Media Literacy Education",
    description: "We offer educational programs to teach critical thinking and media analysis skills to all ages.",
    icon: "GraduationCap",
    color: "lightBlue",
  },
];

export const differentiators = [
  {
    id: 1,
    title: "Complete Independence",
    description: "Unlike other fact-checking organizations, we're fully independent from media companies, social platforms, and political parties.",
    icon: "Shield",
    color: "primary",
  },
  {
    id: 2,
    title: "Educational Focus",
    description: "We don't just tell you what's true—we teach you how to identify misinformation yourself through critical thinking skills.",
    icon: "BookOpen",
    color: "secondary",
  },
  {
    id: 3,
    title: "Community-Powered",
    description: "Our verification methods leverage both expert analysis and community input, creating a more robust fact-checking system.",
    icon: "Users",
    color: "accent",
  },
  {
    id: 4,
    title: "Technological Innovation",
    description: "We develop cutting-edge AI tools that help identify misinformation patterns while maintaining human oversight.",
    icon: "Cpu",
    color: "primary",
  },
  {
    id: 5,
    title: "Global Reach",
    description: "Our network spans multiple languages and regions, allowing us to address misinformation across cultural and geographical divides.",
    icon: "Globe",
    color: "secondary",
  },
  {
    id: 6,
    title: "Proactive Approach",
    description: "Rather than just reacting to viral falsehoods, we proactively identify and verify trending claims before they spread widely.",
    icon: "Trending",
    color: "accent",
  },
];

export const testimonials = [
  {
    id: 1,
    quote: "The Truth Networks Foundation helped our school district implement critical media literacy programs that have fundamentally changed how our students engage with information online.",
    author: "Dr. Maria Sanchez",
    position: "School District Superintendent",
    rating: 5,
  },
  {
    id: 2,
    quote: "As a journalist, I rely on TNF's verification tools daily. Their speed and accuracy are unmatched, and they've become an essential resource in my reporting process.",
    author: "James Townsend",
    position: "Investigative Reporter",
    rating: 5,
  },
  {
    id: 3,
    quote: "The training our community leaders received from the Truth Networks Foundation has empowered us to combat health misinformation that was causing real harm in our neighborhood.",
    author: "Aisha Williams",
    position: "Community Health Advocate",
    rating: 5,
  },
];
