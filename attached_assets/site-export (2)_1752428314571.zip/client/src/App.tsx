import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import HomePage from "@/pages/HomePage";
import AboutPage from "@/pages/AboutPage";
import OurWorkPage from "@/pages/OurWorkPage";
import ContactPage from "@/pages/ContactPage";
import ContributePage from "@/pages/ContributePage";
import VolunteerPage from "@/pages/VolunteerPage";
import FactCheckPage from "@/pages/FactCheckPage";
import K12EducationPage from "@/pages/K12EducationPage";
import CommunityWorkshopsPage from "@/pages/CommunityWorkshopsPage";
import JournalismSupportPage from "@/pages/JournalismSupportPage";
import SpottingFakeNewsPage from "@/pages/SpottingFakeNewsPage";
import UnderstandingMediaBiasPage from "@/pages/UnderstandingMediaBiasPage";
import RealTimeFactCheckingPage from "@/pages/RealTimeFactCheckingPage";
import PrototypePage from "@/pages/PrototypePage";
import OneRoomSchoolHousePage from "@/pages/OneRoomSchoolHousePage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/our-work" component={OurWorkPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/contribute" component={ContributePage} />
      <Route path="/volunteer" component={VolunteerPage} />
      <Route path="/fact-check" component={FactCheckPage} />
      <Route path="/k12-education" component={K12EducationPage} />
      <Route path="/community-workshops" component={CommunityWorkshopsPage} />
      <Route path="/journalism-support" component={JournalismSupportPage} />
      <Route path="/spotting-fake-news" component={SpottingFakeNewsPage} />
      <Route path="/understanding-media-bias" component={UnderstandingMediaBiasPage} />
      <Route path="/real-time-fact-checking" component={RealTimeFactCheckingPage} />
      <Route path="/prototype" component={PrototypePage} />
      <Route path="/one-room-school-house" component={OneRoomSchoolHousePage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow">
          <Router />
        </main>
        <Footer />
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
