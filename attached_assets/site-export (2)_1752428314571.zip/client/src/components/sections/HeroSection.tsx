import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section id="home" className="hero-gradient text-white pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            Empowering Truth in a Digital World
          </h1>
          <p className="text-xl md:text-2xl mb-10 text-light">
            Building networks that promote transparency, accuracy, and authentic connections.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="#mission">
              <Button className="bg-primary hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-md shadow-lg transition duration-300 h-auto">
                Our Mission
              </Button>
            </a>
            <a href="#contact">
              <Button variant="outline" className="bg-white hover:bg-gray-100 text-dark font-bold py-3 px-8 rounded-md shadow-lg transition duration-300 h-auto">
                Get In Touch
              </Button>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
