import { coreValues } from "@/lib/data";
import { Check } from "lucide-react";

export default function MissionSection() {
  return (
    <section id="mission" className="py-20 bg-light">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Mission</h2>
            <div className="w-20 h-1 bg-primary mx-auto mb-8"></div>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              At The Truth Networks, we strive to create a more informed, connected world by providing innovative digital solutions that prioritize accuracy and transparency.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                alt="Team working together" 
                className="rounded-lg shadow-lg"
              />
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-4 text-dark">Our Core Values</h3>
              
              {coreValues.map((value) => (
                <div className="mb-6" key={value.id}>
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-1">
                      <div className={`w-10 h-10 rounded-full bg-${value.color} flex items-center justify-center text-white`}>
                        <Check className="h-5 w-5" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h4 className="text-xl font-semibold mb-2">{value.title}</h4>
                      <p className="text-gray-600">{value.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
