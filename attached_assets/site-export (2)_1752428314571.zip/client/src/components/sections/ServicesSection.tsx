import { services } from "@/lib/data";
import { ChevronRight, Network, Shield, Users, Lightbulb, Edit3, Beaker } from "lucide-react";

// Icon mapping
const iconMap: Record<string, React.ReactNode> = {
  Network: <Network className="h-8 w-8" />,
  Shield: <Shield className="h-8 w-8" />,
  Users: <Users className="h-8 w-8" />,
  Lightbulb: <Lightbulb className="h-8 w-8" />,
  Edit3: <Edit3 className="h-8 w-8" />,
  Beaker: <Beaker className="h-8 w-8" />,
};

export default function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Services</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We provide comprehensive solutions to help organizations build trust and authentic connections through technology.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div
              key={service.id}
              className="bg-light rounded-lg shadow-lg overflow-hidden transition-transform hover:transform hover:scale-105"
            >
              <div className="p-8">
                <div className={`w-14 h-14 rounded-full bg-${service.color}/20 flex items-center justify-center mb-6`}>
                  <div className={`text-${service.color}`}>
                    {iconMap[service.icon]}
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <a
                  href="#"
                  className={`text-${service.color} font-semibold inline-flex items-center`}
                >
                  Learn More
                  <ChevronRight className="h-4 w-4 ml-1" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
