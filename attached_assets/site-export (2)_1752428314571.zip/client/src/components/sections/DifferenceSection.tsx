import { differentiators } from "@/lib/data";
import { Shield, Users, Zap, Scale, User, Building } from "lucide-react";

// Icon mapping
const iconMap: Record<string, React.ReactNode> = {
  Shield: <Shield className="h-8 w-8" />,
  Users: <Users className="h-8 w-8" />,
  Zap: <Zap className="h-8 w-8" />,
  Scale: <Scale className="h-8 w-8" />,
  User: <User className="h-8 w-8" />,
  Building: <Building className="h-8 w-8" />,
};

export default function DifferenceSection() {
  return (
    <section id="difference" className="py-20 bg-dark text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Why We're Different</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-8"></div>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Our unique approach sets us apart from traditional technology providers and consultants.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {differentiators.map((item) => (
            <div className="text-center" key={item.id}>
              <div className="bg-dark shadow-lg border border-gray-700 rounded-lg p-6 h-full">
                <div className={`w-16 h-16 mx-auto mb-6 bg-${item.color}/30 rounded-full flex items-center justify-center`}>
                  <div className={`text-${item.color}`}>
                    {iconMap[item.icon]}
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                <p className="text-gray-300">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
