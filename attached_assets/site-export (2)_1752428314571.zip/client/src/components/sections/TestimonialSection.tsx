import { useState } from "react";
import { testimonials } from "@/lib/data";
import { Star } from "lucide-react";

export default function TestimonialSection() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  return (
    <section className="py-20 bg-light">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Partners Say</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-8"></div>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="bg-white shadow-lg rounded-lg p-8 mb-8">
            <div className="text-center">
              <div className="flex justify-center mb-6">
                {/* Star Rating */}
                {Array.from({ length: testimonials[activeTestimonial].rating }).map((_, index) => (
                  <Star key={index} className="h-6 w-6 text-accent fill-current" />
                ))}
              </div>
              
              <p className="text-xl italic font-serif mb-8">"{testimonials[activeTestimonial].quote}"</p>
              
              <div>
                <p className="font-bold text-lg">{testimonials[activeTestimonial].author}</p>
                <p className="text-gray-600">{testimonials[activeTestimonial].position}</p>
              </div>
            </div>
          </div>
          
          {/* Testimonial Navigation */}
          <div className="flex justify-center">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`w-3 h-3 mx-1 rounded-full ${
                  index === activeTestimonial ? "bg-primary" : "bg-gray-300"
                }`}
                aria-label={`Testimonial ${index + 1}`}
                onClick={() => setActiveTestimonial(index)}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
