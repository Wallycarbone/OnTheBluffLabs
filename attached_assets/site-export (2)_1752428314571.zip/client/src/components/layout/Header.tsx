import { useState } from "react";
import { Link, useLocation } from "wouter";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <header className="bg-[#276EF1] shadow-sm sticky top-0 z-50">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex-shrink-0">
            <Link href="/" className="font-bold text-white text-lg">
              THE TRUTH NETWORKS
            </Link>
          </div>
          
          {/* Mobile menu button */}
          <div className="sm:hidden">
            <button 
              type="button" 
              onClick={toggleMobileMenu}
              className="text-white hover:text-gray-100 focus:outline-none"
            >
              <i className="fas fa-bars text-xl"></i>
            </button>
          </div>
          
          {/* Desktop navigation */}
          <nav className="hidden sm:flex space-x-6">
            <Link 
              href="/about" 
              className={`font-medium ${isActive('/about') ? 'text-white font-bold' : 'text-white hover:text-gray-100'} transition-all`}
            >
              ABOUT
            </Link>
            <Link 
              href="/our-work" 
              className={`font-medium ${isActive('/our-work') ? 'text-white font-bold' : 'text-white hover:text-gray-100'} transition-all`}
            >
              OUR WORK
            </Link>
            <Link 
              href="/prototype" 
              className={`font-medium ${isActive('/prototype') ? 'text-white font-bold' : 'text-white hover:text-gray-100'} transition-all`}
            >
              PROTOTYPE
            </Link>
            <Link 
              href="/one-room-school-house" 
              className={`font-medium ${isActive('/one-room-school-house') ? 'text-white font-bold' : 'text-white hover:text-gray-100'} transition-all`}
            >
              SCHOOL HOUSE
            </Link>
            <Link 
              href="/contact" 
              className={`font-medium ${isActive('/contact') ? 'text-white font-bold' : 'text-white hover:text-gray-100'} transition-all`}
            >
              CONTACT
            </Link>
            <Link 
              href="/volunteer" 
              className={`font-medium ${isActive('/volunteer') ? 'text-white font-bold' : 'text-white hover:text-gray-100'} transition-all`}
            >
              VOLUNTEER
            </Link>
            <Link 
              href="/contribute" 
              className="bg-[#FF8C00] text-white font-bold px-5 py-2 rounded hover:bg-[#E65100] transition-all"
            >
              CONTRIBUTE
            </Link>
          </nav>
        </div>
      </div>
      
      {/* Mobile navigation */}
      <div className={`sm:hidden ${isMobileMenuOpen ? '' : 'hidden'} bg-[#276EF1] border-t border-blue-400`}>
        <div className="px-2 pt-2 pb-3 space-y-1">
          <Link 
            href="/about" 
            className={`block px-3 py-2 text-base font-medium ${isActive('/about') ? 'text-white font-bold' : 'text-white hover:text-gray-100'}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            ABOUT
          </Link>
          <Link 
            href="/our-work" 
            className={`block px-3 py-2 text-base font-medium ${isActive('/our-work') ? 'text-white font-bold' : 'text-white hover:text-gray-100'}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            OUR WORK
          </Link>
          <Link 
            href="/prototype" 
            className={`block px-3 py-2 text-base font-medium ${isActive('/prototype') ? 'text-white font-bold' : 'text-white hover:text-gray-100'}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            PROTOTYPE
          </Link>
          <Link 
            href="/one-room-school-house" 
            className={`block px-3 py-2 text-base font-medium ${isActive('/one-room-school-house') ? 'text-white font-bold' : 'text-white hover:text-gray-100'}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            SCHOOL HOUSE
          </Link>
          <Link 
            href="/contact" 
            className={`block px-3 py-2 text-base font-medium ${isActive('/contact') ? 'text-white font-bold' : 'text-white hover:text-gray-100'}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            CONTACT
          </Link>
          <Link 
            href="/volunteer" 
            className={`block px-3 py-2 text-base font-medium ${isActive('/volunteer') ? 'text-white font-bold' : 'text-white hover:text-gray-100'}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            VOLUNTEER
          </Link>
          <Link 
            href="/contribute" 
            className="block px-3 py-2 text-base font-medium bg-[#FF8C00] text-white rounded hover:bg-[#E65100]"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            CONTRIBUTE
          </Link>
        </div>
      </div>
    </header>
  );
}
