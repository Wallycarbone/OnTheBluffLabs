import { Link } from "wouter";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !email.includes('@')) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await apiRequest('POST', '/api/newsletter', { email });
      toast({
        title: "Success!",
        description: "You've been subscribed to our newsletter.",
      });
      setEmail("");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to subscribe. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <footer className="bg-[#0B1D3A] text-white py-12">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div>
            <h3 className="font-bold text-lg mb-4 text-white">The Truth Networks</h3>
            <div className="bg-[rgba(255,255,255,0.1)] p-4 rounded-md border border-[rgba(255,255,255,0.2)]">
              <p className="text-white font-medium mb-2">
                Fighting misinformation and promoting media literacy in a digital age.
              </p>
              <p className="text-gray-300">
                165 Northern Blvd, Germantown, NY 12526
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4 text-white">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-gray-300 hover:text-white">About Us</Link></li>
              <li><Link href="/our-work" className="text-gray-300 hover:text-white">Our Work</Link></li>
              <li><Link href="/contact" className="text-gray-300 hover:text-white">Contact</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4 text-white">Programs</h3>
            <ul className="space-y-2">
              <li><Link href="/fact-check" className="text-gray-300 hover:text-white">Fact-Checking Tool</Link></li>
              <li><Link href="/our-work" className="text-gray-300 hover:text-white">Education Initiatives</Link></li>
              <li><Link href="/our-work" className="text-gray-300 hover:text-white">Research</Link></li>
              <li><Link href="/our-work" className="text-gray-300 hover:text-white">Partnerships</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4 text-white">Newsletter</h3>
            <p className="text-gray-300 mb-4">
              Stay updated with our latest news and resources.
            </p>
            <form className="space-y-3" onSubmit={handleSubmit}>
              <input 
                type="email" 
                placeholder="Your email address" 
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#276EF1] bg-white text-dark-charcoal"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <button 
                type="submit" 
                className="w-full bg-[#276EF1] hover:bg-[#1d5dc9] text-white font-semibold py-2 px-4 rounded-md transition-all"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Subscribing...' : 'Subscribe'}
              </button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-[rgba(255,255,255,0.2)] mt-10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-300 text-sm">
              &copy; {new Date().getFullYear()} The Truth Networks. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="/about" className="text-gray-300 hover:text-white text-sm">Privacy Policy</Link>
              <Link href="/about" className="text-gray-300 hover:text-white text-sm">Terms of Service</Link>
              <Link href="/about" className="text-gray-300 hover:text-white text-sm">Accessibility</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
