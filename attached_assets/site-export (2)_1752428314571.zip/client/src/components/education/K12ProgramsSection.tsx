import { Link } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

interface Program {
  id: number;
  icon: string;
  title: string;
  ageGroup: string;
  description: string;
  features: string[];
}

function ProgramCard({ program }: { program: Program }) {
  return (
    <Card className="h-full transition-all hover:shadow-lg">
      <CardHeader className="pb-4">
        <div className="mb-4 flex justify-center">
          <div className="rounded-full p-4 bg-primary/10 text-primary">
            <i className={`fas ${program.icon} text-2xl`}></i>
          </div>
        </div>
        <CardTitle className="text-xl text-center">{program.title}</CardTitle>
        <p className="text-sm text-center text-muted-foreground">{program.ageGroup}</p>
      </CardHeader>
      <CardContent>
        <CardDescription className="mb-4">{program.description}</CardDescription>
        <ul className="space-y-2">
          {program.features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <span className="mr-2 mt-1 text-primary"><i className="fas fa-check-circle"></i></span>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter className="flex justify-center pt-4">
        <Link href="/our-work">
          <Button variant="outline">Learn More</Button>
        </Link>
      </CardFooter>
    </Card>
  );
}

export default function K12ProgramsSection() {
  const [showFullDetails, setShowFullDetails] = useState(false);

  const toggleDetails = () => {
    setShowFullDetails(!showFullDetails);
  };

  const programs: Program[] = [
    {
      id: 1,
      icon: "fa-child",
      title: "Elementary Media Literacy",
      ageGroup: "Grades K-5",
      description: "Fun, interactive lessons that teach young students the basics of media literacy through stories and games.",
      features: [
        "Age-appropriate digital citizenship lessons",
        "Engaging classroom activities",
        "Colorful worksheets and visual aids",
        "Parent involvement resources"
      ]
    },
    {
      id: 2,
      icon: "fa-school",
      title: "Middle School Critical Thinking",
      ageGroup: "Grades 6-8",
      description: "Developing critical thinking skills that help pre-teens navigate social media and online content responsibly.",
      features: [
        "Social media literacy workshops",
        "Real-world examples analysis",
        "Peer-to-peer learning activities",
        "Digital footprint awareness"
      ]
    },
    {
      id: 3,
      icon: "fa-graduation-cap",
      title: "High School Fact-Checking",
      ageGroup: "Grades 9-12",
      description: "Advanced curriculum teaching teens to identify misinformation and apply journalistic verification techniques.",
      features: [
        "Source verification training",
        "Research methodology skills",
        "News literacy certification",
        "Student fact-checking projects"
      ]
    },
    {
      id: 4,
      icon: "fa-chalkboard-teacher",
      title: "Educator Resources",
      ageGroup: "K-12 Teachers",
      description: "Comprehensive toolkit for educators to integrate media literacy across subjects and grade levels.",
      features: [
        "Professional development workshops",
        "Ready-to-use lesson plans",
        "Cross-curricular integration guides",
        "Assessment tools and rubrics"
      ]
    }
  ];

  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block p-3 rounded-lg bg-primary/10 mb-4">
            <i className="fas fa-book-reader text-primary text-3xl"></i>
          </div>
          <h2 className="text-3xl font-bold mb-4">K-12 Media Literacy Programs</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Empowering the next generation with essential skills to navigate today's complex media landscape, think critically, and become responsible digital citizens.
          </p>
        </div>
        
        <div className="bg-white shadow-md rounded-lg p-6 mb-16">
          <div className="mb-6">
            <h3 className="text-2xl font-bold mb-3">Program Overview</h3>
            <p className="text-gray-700 mb-4">
              Our goal is to equip students with critical thinking, ethical awareness, and analytical skills to navigate and contribute to today's complex media landscape.
            </p>

            {!showFullDetails ? (
              <div className="text-center mt-4">
                <button 
                  onClick={toggleDetails}
                  className="inline-flex items-center text-primary font-medium hover:text-primary/80 transition-colors"
                >
                  Learn More <i className="fas fa-arrow-down ml-2"></i>
                </button>
              </div>
            ) : (
              <div className="mt-6 animate-fadeIn">
                <h4 className="text-xl font-semibold mb-4">Grade-Level Breakdown</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
                  <div className="border border-gray-200 rounded-lg p-5">
                    <h5 className="text-lg font-semibold mb-3">K–2: Foundations of Media Awareness</h5>
                    <div>
                      <p className="font-medium mb-2">Focus Areas:</p>
                      <ul className="list-disc pl-5 mb-4 space-y-1">
                        <li>Recognizing different types of media (books, TV, videos, games).</li>
                        <li>Understanding media as messages created by people.</li>
                        <li>Simple ideas of fairness and truth ("Is this real?").</li>
                      </ul>
                      
                      <p className="font-medium mb-2">Activities:</p>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Picture analysis ("What's happening in this image?").</li>
                        <li>Story comparisons (fiction vs. nonfiction).</li>
                        <li>Role-playing creators (e.g., making simple ads or videos).</li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="border border-gray-200 rounded-lg p-5">
                    <h5 className="text-lg font-semibold mb-3">Grades 3–5: Understanding Media Messages</h5>
                    <div>
                      <p className="font-medium mb-2">Focus Areas:</p>
                      <ul className="list-disc pl-5 mb-4 space-y-1">
                        <li>Basic advertising techniques and intent.</li>
                        <li>Introduction to fact vs. opinion.</li>
                        <li>Simple digital safety and privacy awareness.</li>
                      </ul>
                      
                      <p className="font-medium mb-2">Activities:</p>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Deconstructing commercials.</li>
                        <li>Identifying purpose and audience in media.</li>
                        <li>Beginning to evaluate sources ("Who made this and why?").</li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="border border-gray-200 rounded-lg p-5">
                    <h5 className="text-lg font-semibold mb-3">Grades 6–8: Evaluating and Creating Media</h5>
                    <div>
                      <p className="font-medium mb-2">Focus Areas:</p>
                      <ul className="list-disc pl-5 mb-4 space-y-1">
                        <li>Recognizing bias and stereotypes.</li>
                        <li>Introduction to misinformation and disinformation.</li>
                        <li>Ethical content creation.</li>
                      </ul>
                      
                      <p className="font-medium mb-2">Activities:</p>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Fact-checking exercises.</li>
                        <li>Media diaries (track media usage).</li>
                        <li>Create PSAs or short news segments.</li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="border border-gray-200 rounded-lg p-5">
                    <h5 className="text-lg font-semibold mb-3">Grades 9–12: Media Power and Civic Responsibility</h5>
                    <div>
                      <p className="font-medium mb-2">Focus Areas:</p>
                      <ul className="list-disc pl-5 mb-4 space-y-1">
                        <li>Media ownership and influence.</li>
                        <li>Algorithms, echo chambers, and filter bubbles.</li>
                        <li>Deep dives into misinformation, propaganda, and censorship.</li>
                        <li>Media and democracy: journalism, activism, and accountability.</li>
                      </ul>
                      
                      <p className="font-medium mb-2">Activities:</p>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Analyzing media coverage of current events.</li>
                        <li>Creating investigative or multimedia reports.</li>
                        <li>Debates on ethical issues in media.</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                <div className="bg-blue-50 rounded-lg p-5 mb-4">
                  <h4 className="text-xl font-semibold mb-3">Cross-Cutting Skills</h4>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Digital literacy and source evaluation.</li>
                    <li>Constructive dialogue and respectful disagreement.</li>
                    <li>Recognizing emotional appeals and manipulation.</li>
                    <li>Media creation with attention to ethics and audience.</li>
                  </ul>
                </div>
                
                <div className="text-center mt-6">
                  <button 
                    onClick={toggleDetails}
                    className="inline-flex items-center text-primary font-medium hover:text-primary/80 transition-colors"
                  >
                    Show Less <i className="fas fa-arrow-up ml-2"></i>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {programs.map(program => (
            <ProgramCard key={program.id} program={program} />
          ))}
        </div>
        
        <div className="mt-16 text-center bg-gray-100 p-8 rounded-lg">
          <h3 className="text-2xl font-bold mb-4">Bring Media Literacy to Your School</h3>
          <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
            Our programs are aligned with educational standards and can be customized to meet the specific needs of your school or district.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/contact">
              <Button className="bg-primary hover:bg-primary/90 text-white">Request a Workshop</Button>
            </Link>
            <Link href="/our-work">
              <Button variant="outline">Download Free Resources</Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}