import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

interface Workshop {
  id: number;
  icon: string;
  title: string;
  audience: string;
  description: string;
  features: string[];
}

function WorkshopCard({ workshop }: { workshop: Workshop }) {
  return (
    <Card className="h-full transition-all hover:shadow-lg">
      <CardHeader className="pb-4">
        <div className="mb-4 flex justify-center">
          <div className="rounded-full p-4 bg-amber-100 text-amber-600">
            <i className={`fas ${workshop.icon} text-2xl`}></i>
          </div>
        </div>
        <CardTitle className="text-xl text-center">{workshop.title}</CardTitle>
        <p className="text-sm text-center text-muted-foreground">{workshop.audience}</p>
      </CardHeader>
      <CardContent>
        <CardDescription className="mb-4">{workshop.description}</CardDescription>
        <ul className="space-y-2">
          {workshop.features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <span className="mr-2 mt-1 text-amber-600"><i className="fas fa-check-circle"></i></span>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter className="flex justify-center pt-4">
        <Link href="/contact">
          <Button variant="outline" className="border-amber-600 text-amber-600 hover:bg-amber-600 hover:text-white">
            Register Interest
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}

export default function CommunityWorkshopsSection() {
  const [showFullDetails, setShowFullDetails] = useState(false);

  const toggleDetails = () => {
    setShowFullDetails(!showFullDetails);
  };

  const workshops: Workshop[] = [
    {
      id: 1,
      icon: "fa-users",
      title: "Public Workshops",
      audience: "General Public",
      description: "Interactive workshops helping community members identify misinformation and develop critical thinking skills.",
      features: [
        "Hands-on fact-checking techniques",
        "Source evaluation strategies",
        "Media bias recognition",
        "Free resources and handouts"
      ]
    },
    {
      id: 2,
      icon: "fa-user-graduate",
      title: "Student Workshops",
      audience: "Teens and Students (Grades 6-12)",
      description: "Age-appropriate sessions teaching students how to evaluate online content and think critically about media.",
      features: [
        "Engaging interactive exercises",
        "Social media literacy skills",
        "Research techniques for school projects",
        "Digital citizenship guidance"
      ]
    },
    {
      id: 3,
      icon: "fa-user-friends",
      title: "Senior Workshops",
      audience: "Seniors & Lifelong Learners",
      description: "Specialized sessions helping older adults navigate today's digital information landscape safely and confidently.",
      features: [
        "Basic fact-checking strategies",
        "Recognizing online scams",
        "Social media safety tips",
        "Peer learning environment"
      ]
    },
    {
      id: 4,
      icon: "fa-laptop-house",
      title: "Virtual Workshops",
      audience: "Online Participants",
      description: "Interactive online sessions accessible from anywhere with the same quality content as in-person workshops.",
      features: [
        "Live instructor interaction",
        "Collaborative exercises",
        "Flexible scheduling options",
        "Recorded sessions for review"
      ]
    }
  ];

  return (
    <section className="pt-4 pb-16 sm:pb-20 bg-white">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <div className="inline-block p-3 rounded-lg bg-amber-100 mb-4">
            <i className="fas fa-handshake text-amber-600 text-3xl"></i>
          </div>
          <h2 className="text-3xl font-bold mb-4">Community Workshops</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Free, local and virtual workshops empowering communities to fight misinformation together.
          </p>
        </div>
        
        <div className="bg-white shadow-md rounded-lg p-6 mb-16">
          <div className="mb-6">
            <h3 className="text-2xl font-bold mb-3">What We Cover</h3>
            <p className="text-gray-700 mb-4">
              Our workshops are open to the public and designed for every age and background. We teach the skills needed to spot false claims, verify sources, and have smarter conversations about what we see online — from social media to news headlines.
            </p>

            {!showFullDetails ? (
              <div className="text-center mt-4">
                <button 
                  onClick={toggleDetails}
                  className="inline-flex items-center text-amber-600 font-medium hover:text-amber-700 transition-colors"
                >
                  Learn More <i className="fas fa-arrow-down ml-2"></i>
                </button>
              </div>
            ) : (
              <div className="mt-6 animate-fadeIn">
                <h4 className="text-xl font-semibold mb-4">Workshop Topics</h4>
                
                <div className="bg-amber-50 rounded-lg p-5 mb-6">
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <span className="mr-3 text-amber-600"><i className="fas fa-search text-lg"></i></span>
                      <span>How to spot misinformation and disinformation</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-3 text-amber-600"><i className="fas fa-check-double text-lg"></i></span>
                      <span>How to fact-check online content in minutes</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-3 text-amber-600"><i className="fas fa-balance-scale text-lg"></i></span>
                      <span>How to evaluate the credibility of sources and images</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-3 text-amber-600"><i className="fas fa-filter text-lg"></i></span>
                      <span>How to understand bias, algorithms, and echo chambers</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-3 text-amber-600"><i className="fas fa-comments text-lg"></i></span>
                      <span>How to talk to others about misinformation constructively</span>
                    </li>
                  </ul>
                </div>
                
                <h4 className="text-xl font-semibold mb-4">Fact-Checking Tools We Teach and Recommend — SEE links below</h4>
                <p className="mb-4">These are free, trusted websites used by journalists, researchers, and educators:</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <a href="https://www.snopes.com/" target="_blank" rel="noreferrer" className="border border-gray-200 rounded-lg p-4 hover:border-amber-300 hover:shadow-md transition-all">
                    <h5 className="text-lg font-semibold mb-2 flex items-center">
                      <span className="mr-2 text-amber-600"><i className="fas fa-search-location"></i></span>
                      Snopes
                    </h5>
                    <p>Investigates rumors, viral stories, and conspiracy theories.</p>
                  </a>
                  
                  <a href="https://www.politifact.com/" target="_blank" rel="noreferrer" className="border border-gray-200 rounded-lg p-4 hover:border-amber-300 hover:shadow-md transition-all">
                    <h5 className="text-lg font-semibold mb-2 flex items-center">
                      <span className="mr-2 text-amber-600"><i className="fas fa-balance-scale"></i></span>
                      PolitiFact
                    </h5>
                    <p>Rates political claims on the Truth-O-Meter.</p>
                  </a>
                  
                  <a href="https://www.factcheck.org/" target="_blank" rel="noreferrer" className="border border-gray-200 rounded-lg p-4 hover:border-amber-300 hover:shadow-md transition-all">
                    <h5 className="text-lg font-semibold mb-2 flex items-center">
                      <span className="mr-2 text-amber-600"><i className="fas fa-clipboard-check"></i></span>
                      FactCheck.org
                    </h5>
                    <p>A nonpartisan resource for checking U.S. political statements and ads.</p>
                  </a>
                  
                  <a href="https://leadstories.com/" target="_blank" rel="noreferrer" className="border border-gray-200 rounded-lg p-4 hover:border-amber-300 hover:shadow-md transition-all">
                    <h5 className="text-lg font-semibold mb-2 flex items-center">
                      <span className="mr-2 text-amber-600"><i className="fas fa-newspaper"></i></span>
                      Lead Stories
                    </h5>
                    <p>Fact-checks trending stories and debunks hoaxes.</p>
                  </a>
                  
                  <a href="https://factcheck.afp.com/" target="_blank" rel="noreferrer" className="border border-gray-200 rounded-lg p-4 hover:border-amber-300 hover:shadow-md transition-all">
                    <h5 className="text-lg font-semibold mb-2 flex items-center">
                      <span className="mr-2 text-amber-600"><i className="fas fa-globe"></i></span>
                      AFP Fact Check
                    </h5>
                    <p>Global fact-checking from Agence France-Presse, especially strong on image and video verification.</p>
                  </a>
                  
                  <a href="https://toolbox.google.com/factcheck/explorer" target="_blank" rel="noreferrer" className="border border-gray-200 rounded-lg p-4 hover:border-amber-300 hover:shadow-md transition-all">
                    <h5 className="text-lg font-semibold mb-2 flex items-center">
                      <span className="mr-2 text-amber-600"><i className="fab fa-google"></i></span>
                      Google Fact Check Explorer
                    </h5>
                    <p>Search engine for fact-checks from reputable organizations.</p>
                  </a>
                  
                  <a href="https://mediabiasfactcheck.com/" target="_blank" rel="noreferrer" className="border border-gray-200 rounded-lg p-4 hover:border-amber-300 hover:shadow-md transition-all">
                    <h5 className="text-lg font-semibold mb-2 flex items-center">
                      <span className="mr-2 text-amber-600"><i className="fas fa-filter"></i></span>
                      Media Bias/Fact Check
                    </h5>
                    <p>Assesses source bias and factual reporting records.</p>
                  </a>
                  
                  <a href="https://www.newsguardtech.com/" target="_blank" rel="noreferrer" className="border border-gray-200 rounded-lg p-4 hover:border-amber-300 hover:shadow-md transition-all">
                    <h5 className="text-lg font-semibold mb-2 flex items-center">
                      <span className="mr-2 text-amber-600"><i className="fas fa-shield-alt"></i></span>
                      NewsGuard
                    </h5>
                    <p>Browser extension that provides trust ratings for news sources (freemium).</p>
                  </a>
                </div>
                
                <a 
                  href="https://infodemic.blog/2020/03/19/sift-the-four-moves/" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="bg-blue-50 p-5 rounded-lg mb-6 block hover:bg-blue-100 transition-all"
                >
                  <h5 className="text-lg font-semibold mb-2 flex items-center">
                    <span className="mr-2 text-blue-600"><i className="fas fa-compass"></i></span>
                    The SIFT Method
                  </h5>
                  <p>A simple, effective 4-step strategy:</p>
                  <ul className="list-disc pl-5 mt-2">
                    <li><strong>S</strong>top</li>
                    <li><strong>I</strong>nvestigate the source</li>
                    <li><strong>F</strong>ind better coverage</li>
                    <li><strong>T</strong>race claims to the original</li>
                  </ul>
                </a>
                
                <div className="text-center mt-6">
                  <button 
                    onClick={toggleDetails}
                    className="inline-flex items-center text-amber-600 font-medium hover:text-amber-700 transition-colors"
                  >
                    Show Less <i className="fas fa-arrow-up ml-2"></i>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {workshops.map(workshop => (
            <WorkshopCard key={workshop.id} workshop={workshop} />
          ))}
        </div>
        
        <div className="mt-16 text-center bg-amber-50 p-8 rounded-lg">
          <h3 className="text-2xl font-bold mb-4">Bring a Workshop to Your School, Library, or Community Center</h3>
          <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
            We offer customized sessions for teens and students, seniors and lifelong learners, parents and educators, and civic organizations and local media.
          </p>
          <p className="text-xl font-bold italic text-gray-800 mb-6">"We believe the truth is a team effort."</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/contact">
              <Button className="bg-amber-600 hover:bg-amber-700 text-white">Get in Touch</Button>
            </Link>
            <Link href="/contact">
              <Button variant="outline">Sign up for Virtual Sessions</Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}