export default function DifferenceSection() {
  return (
    <section className="py-16 sm:py-20">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-8">Why We're Different</h2>
        
        <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
          <p className="text-lg text-gray-700 mb-6">
            While tech platforms and traditional media struggle with bias, click incentives, and opaque algorithms, The Truth Networks exists outside that system. We're not owned by a media conglomerate. We're not driven by ad revenue. And we don't tailor our content to trends, outrage, or influence.
          </p>
          
          <p className="text-lg text-gray-700 mb-6">
            Instead, we're powered by people — educators, fact-checkers, developers, and citizens — committed to protecting the public's right to truth. Our verification engine draws from over 40 independently vetted data sources, not a single platform's feed. Our tools are open, our methods are transparent, and our mission is public good — not private gain.
          </p>
          
          <p className="text-lg text-gray-700 italic font-medium text-center mt-8">
            In a world built to manipulate attention, we stand for informed intention.
          </p>
        </div>
      </div>
    </section>
  );
}