import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface FactCheckResult {
  rating: string;
  ratingClass: string;
  analysisDate: string;
  analysis: string;
  truthful: string;
  misleading: string;
}

export default function FactCheckToolSection() {
  const [claimText, setClaimText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<FactCheckResult | null>(null);
  const [showResults, setShowResults] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!claimText.trim()) {
      toast({
        title: "Empty claim",
        description: "Please enter a statement to verify.",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    setShowResults(true);
    
    try {
      const response = await apiRequest('POST', '/api/fact-check', { text: claimText });
      const data = await response.json();
      setResult(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to check the claim. Please try again.",
        variant: "destructive"
      });
      setShowResults(false);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="py-16 sm:py-20">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center gap-10">
          <div className="w-full md:w-1/2">
            <h2 className="text-3xl font-bold mb-6">Try Our Fact-Checking Tool</h2>
            <p className="text-lg text-gray-700 mb-6">
              Our AI-powered tool helps you verify information quickly and accurately. Just paste a claim, article, or statement to analyze its credibility.
            </p>
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <i className="fas fa-check-circle text-[#2e7d32] mt-1 mr-3"></i>
                <span>Analyzes sources and credibility</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-[#2e7d32] mt-1 mr-3"></i>
                <span>Checks against verified facts database</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-[#2e7d32] mt-1 mr-3"></i>
                <span>Identifies potential bias or misleading language</span>
              </li>
            </ul>
          </div>
          
          <div className="w-full md:w-1/2 bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold mb-4">Verify a Claim</h3>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <textarea 
                  placeholder="Paste a statement, claim, or paragraph to verify..." 
                  className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  rows={5}
                  value={claimText}
                  onChange={(e) => setClaimText(e.target.value)}
                  required
                ></textarea>
              </div>
              <button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 px-4 rounded-md transition-all"
                disabled={isLoading}
              >
                {isLoading ? 'Analyzing...' : 'Check Accuracy'}
              </button>
            </form>
            
            {showResults && (
              <div className="mt-8">
                {isLoading ? (
                  <div className="flex justify-center py-6">
                    <i className="fas fa-circle-notch fa-spin text-3xl text-gray-400"></i>
                  </div>
                ) : result ? (
                  <div className="border rounded-md p-5 bg-gray-50">
                    <div className="flex items-center mb-4">
                      <div className={`${result.ratingClass} px-3 py-1 rounded-md font-medium mr-3`}>
                        {result.rating}
                      </div>
                      <div className="text-sm text-gray-500">
                        Analyzed on <span>{result.analysisDate}</span>
                      </div>
                    </div>
                    
                    <h4 className="font-bold mb-2">Analysis:</h4>
                    <p className="text-gray-700 mb-4">
                      {result.analysis}
                    </p>
                    
                    <h4 className="font-bold mb-2">What's true:</h4>
                    <p className="text-gray-700 mb-4">
                      {result.truthful}
                    </p>
                    
                    <h4 className="font-bold mb-2">What's missing or misleading:</h4>
                    <p className="text-gray-700">
                      {result.misleading}
                    </p>
                  </div>
                ) : null}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
