import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function SpottingFakeNewsSection() {
  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">🕵️‍♂️ Guide to Spotting Fake News</h2>
          <p className="text-lg text-gray-700">
            Learn the telltale signs of misinformation — and how to verify before you share.
          </p>
        </div>
        
        <div className="mb-12">
          <p className="text-gray-700 max-w-4xl mx-auto text-center mb-12">
            In an age where misinformation spreads faster than facts, knowing how to spot fake news isn't just smart — it's essential. 
            Here's how to protect yourself (and your community) from getting fooled:
          </p>
          
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-white rounded-lg shadow-md p-8">
              <h3 className="text-xl font-bold text-red-600 mb-6">⚠️ Red Flags of Fake News</h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold text-gray-800">Sensational Headlines</h4>
                  <p className="text-gray-600">If it sounds too outrageous or dramatic to be true... it probably is.</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-gray-800">No Author or Source</h4>
                  <p className="text-gray-600">Legitimate news outlets cite reporters and sources. Be skeptical of anonymous claims.</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-gray-800">Spelling & Grammar Errors</h4>
                  <p className="text-gray-600">Many fake stories are rushed or poorly written. That's a giveaway.</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-gray-800">Emotion Over Facts</h4>
                  <p className="text-gray-600">If the article's goal is to make you angry or afraid — not inform you — step back.</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-gray-800">No Publication Date or Context</h4>
                  <p className="text-gray-600">Fake news often recycles old stories or removes crucial info.</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-gray-800">One-Sided or Biased Reporting</h4>
                  <p className="text-gray-600">Check if it gives all sides of the story. If it reads like a rant, it's probably not journalism.</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-8">
              <h3 className="text-xl font-bold text-blue-600 mb-6">🛠️ How to Check a Story</h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold text-gray-800">Use Our Fact-Checking Tools</h4>
                  <p className="text-gray-600">Search claims on Snopes, PolitiFact, or FactCheck.org.</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-gray-800">Google the Headline</h4>
                  <p className="text-gray-600">See if other credible outlets are reporting it — or debunking it.</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-gray-800">Check the URL</h4>
                  <p className="text-gray-600">Scam sites often imitate real ones (e.g., "cnn.com.co" is not CNN).</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-gray-800">Use Reverse Image Search</h4>
                  <p className="text-gray-600">Right-click a photo and select "Search image with Google" to see where it really came from.</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-gray-800">Look Up the Source</h4>
                  <p className="text-gray-600">Use Media Bias/Fact Check to assess the reliability of unfamiliar sites.</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-gray-800">Use the SIFT Method</h4>
                  <p className="text-gray-600">Stop, Investigate the source, Find better coverage, Trace the claim to its original.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8 max-w-3xl mx-auto">
            <h3 className="text-xl font-bold text-green-600 mb-6">✅ Before You Share, Ask:</h3>
            
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-green-600 mr-2">•</span>
                <span>Is this from a trustworthy source?</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-600 mr-2">•</span>
                <span>Can I verify it with a second source?</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-600 mr-2">•</span>
                <span>Is it recent and in context?</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-600 mr-2">•</span>
                <span>Am I sharing it just because it confirms my beliefs?</span>
              </li>
            </ul>
            
            <div className="mt-6 text-center font-bold text-gray-700">
              Sharing is power. Use it responsibly.
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <p className="text-lg text-gray-700 max-w-2xl mx-auto mb-6">
            Misinformation thrives when we don't pause to think. Be part of the solution — not the spread.
          </p>
          
          <Link href="/fact-check" className="inline-flex items-center">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              Try Our Fact-Checking Tool
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="hidden lg:block absolute top-0 left-0 -mt-16 -ml-16">
        <div className="w-64 h-64 bg-blue-50 rounded-full opacity-30"></div>
      </div>
      <div className="hidden lg:block absolute bottom-0 right-0 -mb-16 -mr-16">
        <div className="w-48 h-48 bg-blue-50 rounded-full opacity-30"></div>
      </div>
    </section>
  );
}