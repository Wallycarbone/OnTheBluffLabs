import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

interface ServiceCardProps {
  icon: string;
  iconBgColor: string;
  iconColor: string;
  title: string;
  description: string;
  extendedDescription?: string;
}

function ServiceCard({ icon, iconBgColor, iconColor, title, description, extendedDescription }: ServiceCardProps) {
  const [expanded, setExpanded] = useState(false);
  
  return (
    <div className="bg-white rounded-lg shadow-md p-8 transition-all hover:shadow-lg">
      <div className={`w-14 h-14 rounded-full ${iconBgColor} flex items-center justify-center mb-6`}>
        <i className={`fas ${icon} ${iconColor} text-xl`}></i>
      </div>
      <h3 className="text-xl font-bold mb-4" dangerouslySetInnerHTML={{ __html: title }}></h3>
      <p className="text-gray-600 mb-4">
        {description}
      </p>
      
      {extendedDescription && (
        <div>
          {expanded && (
            <div className="text-gray-600 mt-4 pt-4 border-t border-gray-200">
              <p className="whitespace-pre-line">{extendedDescription}</p>
            </div>
          )}
          
          <button 
            onClick={() => setExpanded(!expanded)}
            className="flex items-center text-primary font-medium mt-4 hover:underline focus:outline-none"
          >
            {expanded ? (
              <>
                <span>Show Less</span>
                <ChevronUp className="ml-1 h-4 w-4" />
              </>
            ) : (
              <>
                <span>Read More</span>
                <ChevronDown className="ml-1 h-4 w-4" />
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
}

export default function ServicesSection() {
  const services = [
    {
      icon: 'fa-check',
      iconBgColor: 'bg-green-100',
      iconColor: 'text-[#2e7d32]',
      title: 'Real-Time<br>Fact-Checking',
      description: 'We deliver instant verification of news and information to combat the spread of falsehoods.',
      extendedDescription: `We monitor breaking news, trending topics, and viral posts across platforms to identify and verify false or misleading claims — often before they go viral. TTN pulls from a network of 40+ reputable, verifiable data sources, including academic institutions, public records, expert databases, and independent fact-checkers.

Our fact-checking is powered by an algorithm built to operate outside the influence of platforms like X, Facebook, and major media outlets. We're not driven by clicks or trends — we're driven by truth. Our team works around the clock to stop misinformation in its tracks and provide the public with clear, accurate context when it matters most.`
    },
    {
      icon: 'fa-desktop',
      iconBgColor: 'bg-blue-100',
      iconColor: 'text-primary',
      title: 'Free Verification<br>Tool',
      description: 'Our open-source tool empowers users to verify the accuracy of content they encounter.',
      extendedDescription: `We believe fact-checking should be for everyone — not just experts. That's why we've created easy-to-use, open-source tools that allow anyone to investigate suspicious content, trace its origin, and evaluate its credibility. Whether you're a student, journalist, educator, or just a curious citizen, our tools are built for transparency, independence, and empowerment.

Unlike platform-integrated features that filter what you see, our tools are free from algorithmic bias and commercial influence. They're designed to support informed decision-making — not engagement metrics.`
    },
    {
      icon: 'fa-graduation-cap',
      iconBgColor: 'bg-blue-50',
      iconColor: 'text-blue-500',
      title: 'Media Literacy<br>Education',
      description: 'We offer educational programs to teach critical thinking and media analysis skills.',
      extendedDescription: `We know that misinformation doesn't just spread because of bad actors — it spreads because people haven't been taught how to spot it. TTN partners with schools, libraries, newsrooms, and civic organizations to offer hands-on programs that teach critical thinking, media analysis, and digital resilience.

Our curriculum is independent, inclusive, and deeply adaptable — reaching students, parents, and communities often left behind by traditional media education efforts. We equip people with lifelong skills to question, verify, and understand the world around them, one headline at a time.`
    }
  ];

  return (
    <section className="py-16 sm:py-20 bg-gray-100">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12">What We Do</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard 
              key={index}
              icon={service.icon}
              iconBgColor={service.iconBgColor}
              iconColor={service.iconColor}
              title={service.title}
              description={service.description}
              extendedDescription={service.extendedDescription}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
