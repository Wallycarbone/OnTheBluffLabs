import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function RealTimeFactCheckingSection() {
  const [activeTab, setActiveTab] = useState("usFact");
  
  return (
    <section className="py-20 bg-[#FFFFFF] relative overflow-hidden">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl font-bold mb-6 text-[#222222]">The Heart of TTN: Real-Time Fact-Checking</h2>
          <p className="text-lg text-[#222222]">
            Our commitment to real-time, accurate information is underpinned by a robust network of 49 verified, 
            unbiased, and reputable databases. This extensive collection serves as the HEART of TTN, ensuring that our 
            fact-checking processes are comprehensive and trustworthy.
          </p>
          <div className="mt-4 p-6 bg-[#EFF6FF] rounded-lg">
            <h3 className="text-lg font-semibold mb-2 text-[#222222]">Why These Sources Are Reliable</h3>
            <ul className="text-left space-y-2 text-[#222222]">
              <li className="flex items-start">
                <span className="text-[#276EF1] mr-2">✓</span>
                <span>They are maintained by public institutions and established fact-checking organizations</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#276EF1] mr-2">✓</span>
                <span>Data collection methods are disclosed and peer-reviewed</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#276EF1] mr-2">✓</span>
                <span>Updates are routine and transparent</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#276EF1] mr-2">✓</span>
                <span>They serve as primary sources, often used by fact-checking organizations themselves</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="flex flex-wrap justify-center gap-3 mb-8">
          <Button 
            onClick={() => setActiveTab("usFact")}
            className={`${activeTab === "usFact" ? "bg-[#276EF1]" : "bg-gray-200 text-gray-800"} font-medium px-5 py-2`}
          >
            U.S. Fact-Checking Sources
          </Button>
          <Button 
            onClick={() => setActiveTab("government")}
            className={`${activeTab === "government" ? "bg-[#276EF1]" : "bg-gray-200 text-gray-800"} font-medium px-5 py-2`}
          >
            Government & Intergovernment Data Sources
          </Button>
          <Button 
            onClick={() => setActiveTab("international")}
            className={`${activeTab === "international" ? "bg-[#276EF1]" : "bg-gray-200 text-gray-800"} font-medium px-5 py-2`}
          >
            International & Multinational Sources
          </Button>
        </div>
        
        {activeTab === "usFact" && (
          <div className="bg-gray-50 rounded-lg p-6 shadow-md">
            <h3 className="text-xl font-bold mb-4">United States-Based Fact-Checking Sources</h3>
            
            <ul className="space-y-4 grid md:grid-cols-2 lg:grid-cols-3 gap-x-6">
              <li className="border-b pb-3">
                <a href="https://www.snopes.com/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Snopes
                </a>
                <p className="text-gray-700">The definitive internet reference source for researching urban legends, folklore, myths, rumors, and misinformation.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.politifact.com/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  PolitiFact
                </a>
                <p className="text-gray-700">A fact-checking website that rates the accuracy of claims by elected officials and others on its Truth-O-Meter.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.factcheck.org/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  FactCheck.org
                </a>
                <p className="text-gray-700">A nonpartisan, nonprofit "consumer advocate" for voters that aims to reduce the level of deception in U.S. politics.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.washingtonpost.com/news/fact-checker/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  The Washington Post Fact Checker
                </a>
                <p className="text-gray-700">Analyzes the statements of political figures regarding issues of great importance, be they national, international, or local.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://leadstories.com/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Lead Stories
                </a>
                <p className="text-gray-700">Tracks story trends and debunks fake news before it becomes viral.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://mediabiasfactcheck.com/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Media Bias/Fact Check
                </a>
                <p className="text-gray-700">Offers comprehensive media bias ratings and detailed fact-checks.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.opensecrets.org/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  OpenSecrets
                </a>
                <p className="text-gray-700">A nonpartisan guide to money's influence on U.S. elections and public policy.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://ballotpedia.org/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Ballotpedia
                </a>
                <p className="text-gray-700">An encyclopedia of American politics and elections.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://checkyourfact.com/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Check Your Fact
                </a>
                <p className="text-gray-700">Dedicated to fact-checking statements and claims made in the media.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.newsguardtech.com/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  NewsGuard
                </a>
                <p className="text-gray-700">Browser extension that provides trust ratings for news sources (freemium).</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://climatefeedback.org/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Climate Feedback
                </a>
                <p className="text-gray-700">A network of scientists who assess the credibility of climate change media coverage.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://healthfeedback.org/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Health Feedback
                </a>
                <p className="text-gray-700">A network of scientists who review the accuracy of influential health and medical media coverage.</p>
              </li>
            </ul>
          </div>
        )}
        
        {activeTab === "government" && (
          <div className="bg-gray-50 rounded-lg p-6 shadow-md">
            <h3 className="text-xl font-bold mb-4">Government & Intergovernment Data Sources</h3>
            
            <ul className="space-y-4 grid md:grid-cols-2 lg:grid-cols-3 gap-x-6">
              <li className="border-b pb-3">
                <a href="https://www.census.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  U.S. Census Bureau
                </a>
                <p className="text-gray-700">Authoritative source for population, housing, economic, and geographic data.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.bls.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Bureau of Labor Statistics (BLS)
                </a>
                <p className="text-gray-700">Employment, wage, inflation, and productivity data.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.cdc.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Centers for Disease Control and Prevention (CDC)
                </a>
                <p className="text-gray-700">Public health information, disease tracking, vaccine data, and studies.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.nih.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  National Institutes of Health (NIH)
                </a>
                <p className="text-gray-700">Biomedical and public health research from the U.S. federal government.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.fda.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Food and Drug Administration (FDA)
                </a>
                <p className="text-gray-700">Regulatory actions, drug/vaccine approvals, food safety alerts.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.fec.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Federal Election Commission (FEC)
                </a>
                <p className="text-gray-700">Campaign finance, contributions, and election data.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.usaspending.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  USAspending.gov
                </a>
                <p className="text-gray-700">Track federal spending, contracts, and grants.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.cbo.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Congressional Budget Office (CBO)
                </a>
                <p className="text-gray-700">Nonpartisan analysis for U.S. Congress, including cost estimates and reports.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://nces.ed.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  National Center for Education Statistics (NCES)
                </a>
                <p className="text-gray-700">Comprehensive data on schools, students, and educational outcomes.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.noaa.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  National Oceanic and Atmospheric Administration (NOAA)
                </a>
                <p className="text-gray-700">Climate, weather, ocean, and atmospheric data.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.epa.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Environmental Protection Agency (EPA)
                </a>
                <p className="text-gray-700">Environmental data, pollution reports, and regulatory actions.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.eia.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  U.S. Energy Information Administration (EIA)
                </a>
                <p className="text-gray-700">Energy statistics, prices, and trends.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.usgs.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  U.S. Geological Survey (USGS)
                </a>
                <p className="text-gray-700">Science on natural resources, natural hazards, and mapping.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://bjs.ojp.gov" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Department of Justice (DOJ) / Bureau of Justice Statistics
                </a>
                <p className="text-gray-700">Criminal justice, law enforcement, and prison system data.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="http://data.un.org" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  United Nations Data (UNdata)
                </a>
                <p className="text-gray-700">Global development, health, and economic indicators.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://data.worldbank.org" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  World Bank Open Data
                </a>
                <p className="text-gray-700">Worldwide development indicators and reports.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.imf.org/en/Data" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  International Monetary Fund (IMF) Data
                </a>
                <p className="text-gray-700">Global economic trends, forecasts, and financial monitoring.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.who.int/data" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  World Health Organization (WHO)
                </a>
                <p className="text-gray-700">International health data, disease tracking, and research.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://data.europa.eu/en" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  European Union Open Data Portal
                </a>
                <p className="text-gray-700">EU policy, economy, environment, and more.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://data.oecd.org" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  OECD Data
                </a>
                <p className="text-gray-700">High-quality comparative data across developed countries.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.statcan.gc.ca" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Statistics Canada
                </a>
                <p className="text-gray-700">Official stats for Canada — economy, population, health.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.ons.gov.uk" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  UK Office for National Statistics (ONS)
                </a>
                <p className="text-gray-700">Official data for the United Kingdom.</p>
              </li>
            </ul>
          </div>
        )}
        
        {activeTab === "international" && (
          <div className="bg-gray-50 rounded-lg p-6 shadow-md">
            <h3 className="text-xl font-bold mb-4">International & Multinational Sources</h3>
            
            <ul className="space-y-4 grid md:grid-cols-2 lg:grid-cols-3 gap-x-6">
              <li className="border-b pb-3">
                <a href="https://www.poynter.org/ifcn/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  International Fact-Checking Network (IFCN)
                </a>
                <p className="text-gray-700">A unit of the Poynter Institute dedicated to bringing together fact-checkers worldwide.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://reporterslab.org/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Duke Reporters' Lab
                </a>
                <p className="text-gray-700">Maintains a database of fact-checking organizations globally.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://africacheck.org/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Africa Check
                </a>
                <p className="text-gray-700">Africa's first independent fact-checking organization.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://fullfact.org/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Full Fact (UK)
                </a>
                <p className="text-gray-700">An independent fact-checking charity based in the UK.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://factcheck.aap.com.au/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Aap FactCheck (Australia)
                </a>
                <p className="text-gray-700">Fact-checking division of the Australian Associated Press.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.abc.net.au/news/factcheck/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  RMIT ABC Fact Check (Australia)
                </a>
                <p className="text-gray-700">A partnership between RMIT University and the Australian Broadcasting Corporation.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.newtral.es/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Newtral (Spain)
                </a>
                <p className="text-gray-700">A Spanish media startup focused on fact-checking and combating misinformation.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://maldita.es/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Maldita.es (Spain)
                </a>
                <p className="text-gray-700">A Spanish non-profit journalistic organization focused on verifying and combating disinformation.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://pagellapolitica.it/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Pagella Politica (Italy)
                </a>
                <p className="text-gray-700">An Italian fact-checking project that verifies statements made by politicians.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://aosfatos.org/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Aos Fatos (Brazil)
                </a>
                <p className="text-gray-700">A Brazilian fact-checking agency dedicated to verifying public statements.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://chequeado.com/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Chequeado (Argentina)
                </a>
                <p className="text-gray-700">The first fact-checking organization in Argentina and the Global South.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.factchecker.in/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  FactChecker.in (India)
                </a>
                <p className="text-gray-700">India's first dedicated fact-checking initiative.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://www.altnews.in/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Alt News (India)
                </a>
                <p className="text-gray-700">An Indian non-profit fact-checking website that debunks misinformation and fake news.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://tfc-taiwan.org.tw/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  Taiwan FactCheck Center
                </a>
                <p className="text-gray-700">A non-profit organization dedicated to fact-checking and combating misinformation in Taiwan.</p>
              </li>
              
              <li className="border-b pb-3">
                <a href="https://factspacewestafrica.org/" target="_blank" rel="noreferrer" className="font-medium text-blue-600 hover:underline block">
                  FactSpace West Africa
                </a>
                <p className="text-gray-700">A fact-checking organization operating in West Africa to combat misinformation.</p>
              </li>
            </ul>
          </div>
        )}
        
        <div className="text-center mt-10">
          <Link href="/fact-check" className="inline-flex items-center">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              Try Our Real-Time Fact Checker
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="hidden lg:block absolute top-0 right-0 -mt-16 -mr-16">
        <div className="w-64 h-64 bg-blue-50 rounded-full opacity-30"></div>
      </div>
      <div className="hidden lg:block absolute bottom-0 left-0 -mb-16 -ml-16">
        <div className="w-48 h-48 bg-blue-50 rounded-full opacity-30"></div>
      </div>
    </section>
  );
}