import { Link } from "wouter";

interface Resource {
  id: number;
  image: string;
  title: string;
  description: string;
  link: string;
}

function ResourceCard({ resource }: { resource: Resource }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg">
      <div className="h-48 bg-gray-200 relative">
        <img 
          src={resource.image} 
          alt={resource.title} 
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold mb-3">{resource.title}</h3>
        <p className="text-gray-600 mb-4">
          {resource.description}
        </p>
        <Link href={resource.link} className="text-primary font-medium hover:text-primary/90">
          Read More <i className="fas fa-arrow-right ml-1"></i>
        </Link>
      </div>
    </div>
  );
}

export default function MediaLiteracySection() {
  const resources: Resource[] = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1591267990532-e5bdb1b0ceb8?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      title: "Guide to Spotting Fake News",
      description: "Learn the telltale signs of misinformation and how to verify sources before sharing.",
      link: "/spotting-fake-news"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      title: "Understanding Media Bias",
      description: "Explore how to identify different types of bias in news reporting and media coverage.",
      link: "/understanding-media-bias"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1594312915251-48db9280c8f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      title: "K-12 Media Literacy Programs",
      description: "Comprehensive educational programs for students of all ages to develop critical thinking skills.",
      link: "/k12-education"
    }
  ];

  return (
    <section className="py-16 sm:py-20 bg-[#F5F5F5]">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12 text-[#222222]">Media Literacy Resources</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {resources.map(resource => (
            <ResourceCard key={resource.id} resource={resource} />
          ))}
        </div>
        
        <div className="text-center mt-12 space-y-4">
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link 
              href="/k12-education" 
              className="inline-block bg-[#276EF1] text-white font-medium px-6 py-3 rounded-md hover:bg-[#1d5dc9] transition-all"
            >
              Explore K-12 Programs <i className="fas fa-graduation-cap ml-2"></i>
            </Link>
            
            <Link 
              href="/our-work" 
              className="inline-block bg-white border border-[#276EF1] text-[#276EF1] hover:bg-[#276EF1] hover:text-white font-medium px-6 py-3 rounded-md transition-all"
            >
              View All Resources <i className="fas fa-arrow-right ml-2"></i>
            </Link>
          </div>
          
          <p className="text-[#222222] max-w-2xl mx-auto">
            Our K-12 programs are designed to empower students with age-appropriate media literacy skills to navigate today's complex information landscape.
          </p>
        </div>
      </div>
    </section>
  );
}
