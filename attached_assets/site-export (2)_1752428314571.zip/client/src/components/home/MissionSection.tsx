export default function MissionSection() {
  return (
    <section className="py-16 sm:py-20 bg-[#F5F5F5]">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-8 text-[#222222]">Our Mission</h2>
        <div className="prose prose-lg max-w-4xl mx-auto text-center text-[#222222]">
          <p className="leading-relaxed">
            In a world flooded with noise and manipulation, The Truth Networks stands for clarity. We confront misinformation at its source — not with fear, but with facts. Through real-time verification, open tools, and trusted education, we help people see clearly, think critically, and rebuild their connection to truth.
          </p>
          <p className="leading-relaxed">
            We operate independently of social platforms, advertisers, and political agendas — because a well-informed public isn't just important, it's essential to democracy and dignity.
          </p>
        </div>
      </div>
    </section>
  );
}
