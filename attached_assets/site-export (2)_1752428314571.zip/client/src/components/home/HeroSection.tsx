import { Link } from "wouter";
import microphoneImage from "@/assets/images/microphone.png";

export default function HeroSection() {
  return (
    <section className="bg-[#276EF1] relative py-20 sm:py-24">
      <div className="absolute inset-0 bg-cover bg-center opacity-90" style={{backgroundImage: `url(${microphoneImage})`}}></div>
      <div className="absolute inset-0 bg-black bg-opacity-20"></div>
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <h1 className="text-white text-4xl sm:text-5xl font-bold leading-tight mb-6 drop-shadow-lg">
          The Truth Networks
        </h1>
        <h2 className="text-white text-2xl sm:text-3xl font-semibold leading-tight mb-6 drop-shadow-lg">
          Fighting misinformation and promoting media literacy in a digital age.
        </h2>
        <p className="text-[#F5F5F5] text-lg mb-8 max-w-3xl mx-auto leading-relaxed font-medium drop-shadow-lg" style={{textShadow: '0 1px 3px rgba(0,0,0,0.8)'}}>
          Empowering communities with real-time fact-checking tools and critical media education to navigate today's complex information landscape. Independent, transparent, and driven by public good — making truth accessible, and disinformation stoppable.
        </p>
        <Link href="/contribute" className="inline-block bg-[#FF8C00] hover:bg-[#E65100] text-white font-bold px-8 py-3 rounded-md text-lg transition-all">
          CONTRIBUTE
        </Link>
      </div>
    </section>
  );
}
