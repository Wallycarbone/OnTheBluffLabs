import { Link } from "wouter";

export default function CtaSection() {
  return (
    <section className="py-16 sm:py-20 bg-[#276EF1] relative">
      <div className="absolute inset-0 bg-cover bg-center opacity-80" style={{backgroundImage: "url('https://images.unsplash.com/photo-1504711434969-e33886168f5c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')"}}></div>
      <div className="absolute inset-0 bg-black bg-opacity-10"></div>
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <h2 className="text-white text-3xl sm:text-4xl font-bold mb-8 drop-shadow-lg" style={{textShadow: '0 2px 4px rgba(0,0,0,0.8)'}}>
          Help us make a difference.<br/>Give today.
        </h2>
        <div className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-6">
          <Link 
            href="/contribute" 
            className="bg-[#FF8C00] hover:bg-[#E65100] text-white font-bold px-8 py-3 rounded-md transition-all"
          >
            CONTRIBUTE
          </Link>
          <Link 
            href="/contact" 
            className="bg-[#14532D] hover:bg-[#1a6538] text-white font-bold px-8 py-3 rounded-md transition-all"
          >
            VOLUNTEER
          </Link>
        </div>
      </div>
    </section>
  );
}
